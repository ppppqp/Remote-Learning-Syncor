debug chat
css
video(统一播放)
chat (显示username)
